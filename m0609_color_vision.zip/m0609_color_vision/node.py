"""Subscribe to camera images and publish the confirmed cube color."""

import math
import os
import time
from collections import Counter

import cv2
import numpy as np
import rclpy
from cv_bridge import CvBridge, CvBridgeError
from rcl_interfaces.msg import ParameterDescriptor
from rclpy.clock import Clock, ClockType
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import QoSProfile, qos_profile_sensor_data
from sensor_msgs.msg import Image
from std_msgs.msg import Int32

from .m0609_color_detector import CameraViewer
from .vision import DEFAULT_RANGES, Stabilizer, detect, validate_ranges


COLOR_IDS = {'blue': 1, 'green': 2}
BOX_COLORS = {'blue': (255, 190, 80), 'green': (80, 235, 80)}


def annotate(image, detections, stable):
    annotated = image.copy()
    counts = Counter(item.color for item in detections)
    for item in detections:
        x, y, width, height = item.box
        center_x, center_y = item.center
        color = BOX_COLORS[item.color]
        cv2.rectangle(annotated, (x, y), (x + width - 1, y + height - 1), color, 2)
        cv2.circle(annotated, item.center, 3, color, -1)
        label = f'{item.color} ({center_x},{center_y}) {item.area:.0f}px^2'
        font = cv2.FONT_HERSHEY_SIMPLEX
        (label_width, _), _ = cv2.getTextSize(label, font, 0.48, 1)
        position = (min(x, max(0, image.shape[1] - label_width - 3)),
                    y - 5 if y >= 54 else min(y + height + 15, image.shape[0] - 5))
        cv2.putText(annotated, label, position, font, 0.48, (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(annotated, label, position, font, 0.48, color, 1, cv2.LINE_AA)

    summary = '  '.join(f'{color.title()}: {counts[color]}' for color in BOX_COLORS)
    cv2.rectangle(annotated, (0, 0), (annotated.shape[1] - 1, 48), (24, 24, 24), -1)
    cv2.putText(annotated, summary, (8, 19), cv2.FONT_HERSHEY_SIMPLEX,
                0.55, (255, 255, 255), 1, cv2.LINE_AA)
    confirmed_label = f'{COLOR_IDS[stable]} ({stable})' if stable in COLOR_IDS else '--'
    cv2.putText(annotated, f'Color ID: {confirmed_label}', (8, 40), cv2.FONT_HERSHEY_SIMPLEX,
                0.5, (255, 255, 255), 1, cv2.LINE_AA)
    return annotated


class ColorDetector(Node):
    def __init__(self, view_camera=False):
        super().__init__('color_detector')
        self.ranges = {
            name: (self.setting(f'{name}_lower', list(lower)),
                   self.setting(f'{name}_upper', list(upper)))
            for name, (lower, upper) in DEFAULT_RANGES.items()
        }
        validate_ranges(self.ranges)
        self.min_area = self.setting('min_area', 500.0)
        self.timeout = self.setting('image_timeout_sec', 1.0)
        required_frames = self.setting('required_frames', 3)
        kernel_size = self.setting('kernel_size', 5)
        if not all(math.isfinite(value) and value > 0 for value in
                   (self.min_area, self.timeout, required_frames, kernel_size)):
            raise ValueError('Area, timeout, frames and kernel size must be positive')
        if kernel_size % 2 == 0:
            raise ValueError('kernel_size must be odd')
        self.kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
        self.filter = Stabilizer(required_frames)
        self.bridge = CvBridge()
        self.gui = self.setting('show_gui', view_camera)
        if self.gui and not (os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY')):
            self.get_logger().warning('No display available. Continuing without GUI.')
            self.gui = False
        self.viewer = CameraViewer() if self.gui else None
        self.last_frame = None
        self.current_color_id = None
        self.waiting_for_camera = True
        self.results = self.create_publisher(Int32, 'color_id', QoSProfile(depth=1))
        self.debug = None
        if self.setting('publish_debug_image', False):
            self.debug = self.create_publisher(Image, 'detected_color/debug_image',
                                               qos_profile_sensor_data)
        self.camera = self.create_subscription(Image, 'rgb', self.on_image,
                                               qos_profile_sensor_data)
        steady_clock = Clock(clock_type=ClockType.STEADY_TIME)
        self.watchdog = self.create_timer(min(0.2, self.timeout / 2), self.check_camera,
                                          clock=steady_clock)
        self.publish_timer = self.create_timer(1.0, self.publish_color_id, clock=steady_clock)

    def setting(self, name, default):
        return self.declare_parameter(name, default, ParameterDescriptor(read_only=True)).value

    def has_recent_frame(self):
        return self.last_frame is not None and time.monotonic() - self.last_frame < self.timeout

    def publish_color_id(self):
        if self.current_color_id is not None and self.has_recent_frame():
            self.results.publish(Int32(data=self.current_color_id))

    def check_camera(self):
        if not self.has_recent_frame():
            self.current_color_id = None
            self.filter.reset()
            if self.viewer is not None and not self.waiting_for_camera:
                self.viewer.draw()
                self.waiting_for_camera = True

    def on_image(self, message):
        now = time.monotonic()
        if self.last_frame is None or now - self.last_frame >= self.timeout:
            self.filter.reset()
        try:
            image = self.bridge.imgmsg_to_cv2(message, desired_encoding='bgr8')
            detections = detect(image, self.ranges, self.min_area, self.kernel)
        except (CvBridgeError, cv2.error, ValueError, TypeError) as error:
            self.get_logger().warning(f'Invalid image ({message.encoding}): {error}',
                                      throttle_duration_sec=5)
            self.last_frame = None
            self.check_camera()
            return
        if self.last_frame is None:
            self.get_logger().info(f'Camera receiving {message.encoding} images')
        self.last_frame = now
        self.waiting_for_camera = False
        primary = detections[0] if detections else None
        confirmed = 'none'
        if primary is None:
            self.filter.reset()
        else:
            previous = self.filter.stable
            stable = self.filter.update(primary.color)
            if stable == primary.color and self.filter.count == self.filter.required_frames:
                confirmed = stable
                if confirmed != previous:
                    self.get_logger().info(
                        f'Color ID: {COLOR_IDS[confirmed]} ({confirmed}), area: {primary.area:.1f} px²'
                    )
        self.current_color_id = COLOR_IDS.get(confirmed)
        if self.gui or self.debug is not None:
            annotated = annotate(image, detections, confirmed)
            if self.debug is not None:
                debug_image = self.bridge.cv2_to_imgmsg(annotated, encoding='bgr8')
                debug_image.header = message.header
                self.debug.publish(debug_image)
            if self.viewer is not None:
                self.viewer.draw(image, annotated)


def main(view_camera=False):
    if view_camera and not (os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY')):
        raise SystemExit('Run view_camera in a graphical desktop session.')
    rclpy.init()
    node = None
    try:
        node = ColorDetector(view_camera=view_camera)
        if node.viewer is None:
            rclpy.spin(node)
        else:
            while rclpy.ok() and node.viewer.is_open():
                rclpy.spin_once(node, timeout_sec=0.025)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    except RuntimeError:
        if rclpy.ok():
            raise
    finally:
        if node is not None:
            if node.gui:
                cv2.destroyAllWindows()
            node.destroy_node()
        rclpy.try_shutdown()
