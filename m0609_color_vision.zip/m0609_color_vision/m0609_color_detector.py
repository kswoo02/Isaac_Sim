"""Display the original and annotated frames side by side."""

import cv2
import numpy as np

WINDOW = 'M0609 Camera'
PANEL_WIDTH = 560
PANEL_HEIGHT = 448
TITLE_HEIGHT = 36


class CameraViewer:
    def __init__(self):
        cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(WINDOW, PANEL_WIDTH * 2, PANEL_HEIGHT + TITLE_HEIGHT)
        self.draw()

    def draw(self, original=None, annotated=None):
        panels = [
            self.draw_panel(original, 'Camera', 'Waiting for camera frames'),
            self.draw_panel(annotated, 'Color detection', 'Waiting for camera frames'),
        ]
        cv2.imshow(WINDOW, np.hstack(panels))

    def is_open(self):
        key = cv2.waitKey(1) & 0xFF
        return key not in (27, ord('q')) and cv2.getWindowProperty(WINDOW, cv2.WND_PROP_VISIBLE) >= 1

    @staticmethod
    def draw_panel(frame, title, waiting):
        panel = np.full((PANEL_HEIGHT + TITLE_HEIGHT, PANEL_WIDTH, 3), 24, dtype=np.uint8)
        cv2.putText(panel, title, (14, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.65,
                    (240, 240, 240), 1, cv2.LINE_AA)
        if frame is None:
            cv2.putText(panel, waiting, (14, TITLE_HEIGHT + 36), cv2.FONT_HERSHEY_SIMPLEX,
                        0.55, (195, 195, 195), 1, cv2.LINE_AA)
            return panel

        height, width = frame.shape[:2]
        scale = min(PANEL_WIDTH / width, PANEL_HEIGHT / height)
        size = (max(1, round(width * scale)), max(1, round(height * scale)))
        resized = cv2.resize(frame, size, interpolation=cv2.INTER_AREA)
        x = (PANEL_WIDTH - size[0]) // 2
        y = TITLE_HEIGHT + (PANEL_HEIGHT - size[1]) // 2
        panel[y:y + size[1], x:x + size[0]] = resized
        return panel


def main():
    from .node import main as run_detector

    run_detector(view_camera=True)
