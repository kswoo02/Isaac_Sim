"""HSV masks and consecutive-frame filtering."""

from dataclasses import dataclass

import cv2
import numpy as np

DEFAULT_RANGES = {
    'green': ((35, 75, 60), (85, 255, 255)),
    'blue': ((95, 75, 60), (135, 255, 255)),
}


@dataclass(frozen=True)
class Detection:
    color: str
    area: float
    box: tuple[int, int, int, int]

    @property
    def center(self):
        x, y, width, height = self.box
        return x + width // 2, y + height // 2


def validate_ranges(ranges):
    for name, (lower, upper) in ranges.items():
        if len(lower) != 3 or len(upper) != 3 or not all(
            0 <= low <= high <= limit
            for low, high, limit in zip(lower, upper, (179, 255, 255))
        ):
            raise ValueError(f'Invalid HSV range: {name}')


def detect(bgr, ranges, min_area, kernel):
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    masks = {
        name: cv2.inRange(hsv, np.array(lower), np.array(upper))
        for name, (lower, upper) in ranges.items()
    }
    detections = []
    for color, mask in masks.items():
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            area = cv2.contourArea(contour)
            if area >= min_area:
                detections.append(Detection(color, area, cv2.boundingRect(contour)))
    return sorted(detections, key=lambda item: -item.area)


class Stabilizer:
    def __init__(self, required_frames):
        self.required_frames = required_frames
        self.reset()

    def reset(self):
        self.stable = self.candidate = 'none'
        self.count = 0

    def update(self, color):
        if color != self.candidate:
            self.candidate = color
            self.count = 0
        self.count = min(self.count + 1, self.required_frames)
        if self.count == self.required_frames:
            self.stable = color
        return self.stable
